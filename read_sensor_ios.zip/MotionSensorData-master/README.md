# MotionSensorData
A simple app that uses CoreMotion framework to obtain and display data from various motion sensors available across iOS devices.
