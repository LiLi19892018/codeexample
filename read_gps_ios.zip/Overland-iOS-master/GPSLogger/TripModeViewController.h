//
//  TripModeViewController.h
//  GPSLogger
//
//  Created by Aaron Parecki on 10/15/15.
//  Copyright © 2015 Aaron Parecki. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TripModeViewController : UIViewController

- (IBAction)tripModeButtonWasTapped:(UITapGestureRecognizer *)sender;

@end
