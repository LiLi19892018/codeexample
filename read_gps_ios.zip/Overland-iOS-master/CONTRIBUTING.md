By contributing to this project, you agree to irrevocably release your contributions under the same license as this project. See README.md for more details.
